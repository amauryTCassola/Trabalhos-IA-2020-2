#!/bin/bash
python3 src/dfs.py $@