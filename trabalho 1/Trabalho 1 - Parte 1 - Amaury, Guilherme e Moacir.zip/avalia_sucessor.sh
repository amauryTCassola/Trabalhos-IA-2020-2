#!/bin/bash
python3 src/sucessor.py $@