#!/bin/bash
python3 src/astar_h1.py $@