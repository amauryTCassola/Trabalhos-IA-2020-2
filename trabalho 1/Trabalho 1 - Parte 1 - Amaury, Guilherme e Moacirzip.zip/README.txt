COMPONENTES DO GRUPO:
    Amaury Teixeira Casola - 287704 - Turma B
    Guilherme Ribeiro Rodrigues - 242299 - Turma A
    Moacir Almeida Simoes Junior - 113330 - Turma A

BIBLIOTECAS:
    Utilizamos as bibliotecas sys (para acessar o input pela linha de comando) e heapq (para utilizar heap no A*). A princípio ambas estão inclusas no Python

BREADTH-FIRST SEARCH:
    Estado inicial: 2_3541687
    Nós expandidos: 101425
    Custo da solução: 23

DEPTH-FIRST SEARCH:
    Estado inicial: 2_3541687
    Nós expandidos: 96841
    Custo da solução: 86069

A* H1:
    Estado inicial: 2_3541687
    Nós expandidos: 13506
    Custo da solução: 23

A* H2:
    Estado inicial: 2_3541687
    Nós expandidos: 1837
    Custo da solução: 23