#!/bin/bash
python3 src/astar_h2.py $@